package com.example.ubimap.persistence.retrofit.data

import com.google.gson.annotations.SerializedName


data class Clouds (

        @SerializedName("all" ) var all : Int? = null

)